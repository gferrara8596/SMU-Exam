﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimentoOggetti : MonoBehaviour
{
    public GameObject OggettoDaSpostare; // definisco un oggetto
    public Transform PuntoIniziale; //definisco un transform che ci servirà come punto iniziale
    public Transform PuntoFinale;//definisco un transform che ci servirà come punto finale
    public float Velocita; //velocità della nostra piattafomra
    private Vector3 Target; // sarà il prossimo obbiettivo per la nostra piattafomra, se abbiamo toccato l'obbiettivo iniziale il 
                            // prossimo obbiettivo sarà il punto finale e così via...

    // Start is called before the first frame update
    void Start()
    {
        Target = PuntoFinale.position;
    }

    // Update is called once per frame
    void Update()
    {
        OggettoDaSpostare.transform.position = Vector3.MoveTowards(OggettoDaSpostare.transform.position, Target, Velocita * Time.deltaTime); //
        
        if (OggettoDaSpostare.transform.position == PuntoFinale.position) // se la piattafoma è arrivata la pt finale 
                                                                           //target diventa la posizione del pt iniziale
        {
            Target = PuntoIniziale.position;
        }
        if (OggettoDaSpostare.transform.position ==PuntoIniziale.position) // se la piattafoma è arrivata la pt iniziale 
                                                                           //target diventa la posizione del pt finale
        {
            Target = PuntoFinale.position;
        }
    }
}
