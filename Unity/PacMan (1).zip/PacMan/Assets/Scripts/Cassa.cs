﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cassa : MonoBehaviour
{
    public Vector3 SpawnPosition; // posizione in cui viene repawnato la nostra cassa
    public GameObject Cassaoggetto;
    // Start is called before the first frame update
    void Start()
    {
        SpawnPosition = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D other) //funzione  che alla collisione con un collider che ha la spunta a istrigger entra nella funzione
    {
        if (other.tag == "Destroyer")//controlla se il tag con cui è colliso è di tipo player
        {
            Cassaoggetto.transform.position = SpawnPosition; //associa la posizione di partenza a quella di spawn
            //qunado l'oggetto viene distrutto verrà rigenerato alla poszione iniziale cioè quella settata
        }
    }

}
