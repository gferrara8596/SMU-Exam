﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelManagment : MonoBehaviour
{
    public float TempoDattesa;//tempo di attesa prima di ricreare il giocatore
    public Movement Movimento; // movment fa riferimento allo script movement.cs 
    public int hp=10;
    public int MaxHp;
    public Slider HeartSlide; // fa riferimento ad un oggetto di tipo Slider (barra della vita)
    private bool rinascita; 
    // Start is called before the first frame update
    void Start()
    {
        Movimento = FindObjectOfType<Movement>();// Nel momento in cui il gioco inizia il nostro moviemento è uguale alla ricerca 
                                                 //dell'oggetto muvment cioè movement è associato ad hero, quindi fa riferimento a lui
        hp = MaxHp;
        HeartSlide.value = hp;
    }

    // Update is called once per frame
    void Update()
    {
        HeartSlide.value = hp;
        if (hp <= 0 && !rinascita) // se i nostri hp sono negativi o uguale a zero e rinascita è falsa
        {
            Respawn();
            rinascita = true; //serve per fargli fare un solo respawing 
        }
    }

    public void Respawn()// funzione che ricostruisce il player
    {
        StartCoroutine(Spawntime()); 
    }

    IEnumerator Spawntime() //funzione che permette di ricostruire il giocatore dopo un certo tempo
    {
        Movimento.gameObject.SetActive(false);// settiamo l'attività del player a falso quindi inattiva
        yield return new WaitForSeconds(TempoDattesa); //permette di eseguire un conto alla rovescia dopo il quale viene ricostruito il giocatore
        hp = MaxHp; //setta i hp agli hp massimi
        rinascita = false;
        Movimento.transform.position = Movimento.SpawnPosition; //la posizione dell'oggetto movimento è uguale alla posizione settata in movment
        Movimento.gameObject.SetActive(true);//riattiviamo l'oggetto
    }
    public void Danneggiare (int Danni)// funzione che crea danni
    {
        hp -= Danni;
    }
}
