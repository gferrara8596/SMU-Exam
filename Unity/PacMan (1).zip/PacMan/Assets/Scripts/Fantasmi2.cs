﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fantasmi2 : MonoBehaviour
{
    public Transform S; //sinistra
    public Transform D;//destra
    public float V;//velocità
    public Rigidbody2D rb;
    private bool Mov=false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Mov && transform.position.x > D.position.x) //se ci stiamo muovendo verso destra e ha ragiunto la posizione destra 
        {
            transform.localScale = new Vector3(-0.4832942f, 0.4832942f, 0.4832942f);//ruota lo sprites del fanstasma
            Mov = false; 
        }
        
        if (!Mov && transform.position.x < S.position.x) //se ci stiamo muovendo verso sinistra e ha ragiunto la posizione sinistra 
        {
            transform.localScale = new Vector3(0.4832942f, 0.4832942f, 0.4832942f);//ruota lo sprites del fanstasma
            Mov = true;
        }
        
        if (Mov)
        {
            rb.velocity = new Vector3(V, rb.velocity.y, 0f);// applica una forza verso destra
        }
        else { rb.velocity = new Vector3(-V, rb.velocity.y, 0f); } //applica una forza verso sinistra
 
     }
}
