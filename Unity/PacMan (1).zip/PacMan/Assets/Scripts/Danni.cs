﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Danni : MonoBehaviour
{
    private LevelManagment levelManagment; //riferimento a levelmangment perchè gestisce il respawn
    public int DanniDaDare;
    // Start is called before the first frame update
    void Start()
    {
        levelManagment = FindObjectOfType<LevelManagment>();// definisco il levelmanagment
    }

    // Update is called once per frame
    void Update()
    {

    }
    void OnTriggerEnter2D(Collider2D other) //funzione  che alla collisione con un collider che ha la spunta a istrigger entra nella funzione
        {
            if (other.tag == "Player")//controlla se il tag con cui è colliso è di tipo player
            {
            levelManagment.Danneggiare(DanniDaDare);// stabilire i danni di ogni elemento
            }
        }

    
}
