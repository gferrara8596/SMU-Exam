﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menu : MonoBehaviour
{
    public GUIStyle StileBottoni;
    public string NomeScena;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(Screen.width / 2 - 250, Screen.height / 2 - 250, 500, 500));
        if (GUILayout.Button("PLAY", StileBottoni))
        {
            Application.LoadLevel(NomeScena);
        }
       if(GUILayout.Button("ESCI", StileBottoni))
        {
            Application.Quit();
        }
        GUILayout.EndArea ();
    }
}
