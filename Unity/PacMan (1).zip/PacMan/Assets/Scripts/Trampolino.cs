﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trampolino : MonoBehaviour
{
    public float Spinta; //aggiunta al salto
    public Movement movimento; //oggetto di tipo movment
    // Start is called before the first frame update
    void Start()
    {
       // movimento = FindObjectsOfType<Movement> ();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D other)//funzione  che alla collisione con un collider che ha la spunta a istrigger entra nella funzione
    {
        if (other.tag == "Player")//controlla se il tag con cui è colliso è di tipo player
        {
            movimento.rb.AddForce(transform.up * Spinta);// aggiunge al rigitbady una forza
        }
    }
}
