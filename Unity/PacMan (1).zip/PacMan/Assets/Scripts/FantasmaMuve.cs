﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FantasmaMuve : MonoBehaviour
{
    public float velocita;
    private bool movimento=true; //stabilisce se ci sta un movimento
    public Rigidbody2D rb; 
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); //associa al movimento un componente rigidbody
    }

    // Update is called once per frame
    void Update()
    {
        if (movimento)
        {
            rb.velocity = new Vector3(-velocita, rb.velocity.y, 0f);//applica una forza al fantasma

        }
    }
    void attivazione() //setta movimento a true
    {
        movimento = true;
    }
    void OnTriggerEnter2D(Collider2D other)//quando il fantsma cade e quindi tocca il destroyer oppure destroyer1 viene distrutto
    {
        if (other.tag == "Destroyer" || other.tag=="Destroyer 1")
        {
            Destroy(gameObject);
        }
    }

}
