﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moneta : MonoBehaviour
{public GestioneMonete GMonete; //dichiaro una variabile di tipo GestioneMonete
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D other)// ongi volta che entri in contatto con la "moneta" si attiva la funzione
    {
        if (other.tag == "Player")
        {
            GMonete.Coins++;// Serve per accedere a gesione monete e aumentare il puneggio delle monete raccolte
            Destroy(gameObject);//distrugge la moneta
        }
    }
}
