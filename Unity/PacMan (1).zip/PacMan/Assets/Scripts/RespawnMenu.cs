﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnMenu : MonoBehaviour
{
    public GUIStyle StileBottoni;
    public string NomeScena1;
    public string NomeScena2;
    public LevelManagment tipo;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(Screen.width / 2 - 250, Screen.height / 2 - 250, 500, 500));
        if (GUILayout.Button("GIOCA ANCORA", StileBottoni))
        {
            Application.LoadLevel(NomeScena2);
            tipo.Respawn();


        }
        if (GUILayout.Button("VAI AL MENU'", StileBottoni))
        {
            Application.LoadLevel(NomeScena1);
        }
        GUILayout.EndArea();
    }
}