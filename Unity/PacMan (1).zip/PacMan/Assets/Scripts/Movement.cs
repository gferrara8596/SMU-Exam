﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour {
	public float Velocità;//VELCOITà DEL giocatore
	public Rigidbody2D rb;// Riferimento al rigibody del nostro player
	public float ForzaSalto;
	public Transform SuoloControllo;//Oggetto che controlla se siamo a contatto con il suolo
	public float SuoloControlloRaggio;//Estensione del suolo
	public LayerMask Suoloè;//Quale layer è il suolo?
	public bool èsuolo;
	private Animator anim;
    public Vector3 SpawnPosition;
    public LevelManagment Levelmanager;
	// Use this for initialization
	void Start () {
        SpawnPosition = transform.position; //mettiamo la posizione del check point all'interno di spawnposition
		rb = GetComponent<Rigidbody2D> ();
		anim=GetComponent<Animator> ();
	}
	public void Jump () //funzione salto
	{
		if(èsuolo) 
		{
			rb.velocity += ForzaSalto * Vector2.up;
	    }
	}
	// Update is called once per frame
	void Update () {
		èsuolo = Physics2D.OverlapCircle (SuoloControllo.position, SuoloControlloRaggio, Suoloè );
		if(Input.GetAxisRaw("Horizontal")>0f)
		{
			rb.velocity = new Vector3 (Velocità, rb.velocity.y, 0f);//Il movimento è dato: dalla velocitàcon la cam
			transform.localScale= new Vector3(0.2420595f,0.2420595f,0.2420595f);
		}else if(Input.GetAxisRaw("Horizontal")<0f) //Stiamo dando un impulso per fare in modo che premendo la freccina dx o d si muova a destra
			{
			rb.velocity = new Vector3 (-Velocità, rb.velocity.y, 0f); //Stiamo dando un impulso per fare in modo che premendo la freccina sx o d si muova a sx
			transform.localScale= new Vector3(-0.2420595f,0.2420595f,0.2420595f);
		}else{
			rb.velocity = new Vector3 (0f, rb.velocity.y, 0f);

	}
		if(Input.GetButtonDown("Jump")&&èsuolo)
		{
			rb.velocity = new Vector3 ( rb.velocity.x,ForzaSalto, 0f);
		}
		anim.SetFloat ("Velocità", Mathf.Abs (rb.velocity.x));
		anim.SetBool ("Suolo", èsuolo);
	}
    void OnTriggerEnter2D(Collider2D other) // funzione del respawn
    {
        if (other.tag == "Destroyer") // quando entra in collisione con un oggetto di tipo destroyer entra nel ciclo
        {
            Levelmanager.hp = 0; // qunado moriamo deve settare gli hp a 0
            Levelmanager.HeartSlide.value = Levelmanager.hp; // passa lla slider il valore degli hp
            Levelmanager.Respawn(); //va alla funzione di repawn
        }
        if (other.tag == "CheckPoint")// quando entra in collisione con un oggetto di tipo checkpoint entra nel ciclo
        {
            SpawnPosition = other.transform.position;
        }
    }
    private void OnCollisionEnter2D(Collision2D other) // funzine che si attiva quando hero entra in contatto con con collider
    {
        if (other.gameObject.tag == "Piattaforma")
        {
            transform.parent = other.transform;//serve per congelare la posizione sulla piattaforma
        }
    }
    private void OnCollisionExit2D(Collision2D other)// quando esce dalla collisione si attiva la funzione
    {
        if (other.gameObject.tag == "Piattaforma")
        {
            transform.parent = null;//scongela hero
        }
    }


}



