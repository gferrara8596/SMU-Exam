﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // serve per usare la libreria di unity dell'UI
public class GestioneMonete : MonoBehaviour
{
    public int Coins=0;//varibile che contera le monete
    private Text CoinText; //riferimento all'oggetto text predente nel canvas
    // Start is called before the first frame update
    void Start()
    {
        CoinText = GetComponent <Text> ();//accede al oggetto testo per farlo aggiornare e tenere traccia del numero di monete prese
        PlayerPrefs.GetInt("Coins", 0); // recupera il numero di monete che abbiamo
    }

    // Update is called once per frame
    void Update()
    {
        CoinText.text = Coins.ToString();//l'oggetto testo sara il uguale al numero di monete
    }
    private void OnDestroy() // funzione che si attiva alla distruzione della scena e serve per salvare le monete
    {
        PlayerPrefs.SetInt("Coins",Coins); //salva il numero di monete in Conis
        PlayerPrefs.Save();
    }
}
